# s-xianyu-fish
## 项目介绍

- 2024.08.21使用vue3重写。
- 微信小程序很好兼容其他没有试过、应该大部分都可以
- https://xy.kuvinet.cn/#/pages/happy/fish

### 预览地址
- 预览地址: https://xy.kuvinet.cn/#/pages/happy/fish

- github地址: https://github.com/s-xianyu/xy-diary

### 应用截图
  [![pi1svwV.png](https://s11.ax1x.com/2023/11/08/pi1svwV.png)](https://imgse.com/i/pi1svwV)

